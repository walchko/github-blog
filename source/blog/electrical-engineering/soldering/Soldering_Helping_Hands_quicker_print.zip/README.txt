                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2757071
Soldering Helping Hands (quicker print) by mistertech is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

*The battery in the picture is just for scale comparison*

This is a complete re-design of my previous rubber band soldering helping hands. I liked the previous one but it was larger than it needed to be. It was after all, one of my very first designs. It took a long time to print and just wasn't very compact to store.

Although my soldering fingers are very popular (https://www.thingiverse.com/thing:1725308), I prefer this because the rubber bands secure the wires better.

The rubber feet recesses are 2mm deep. At first this seems deeper than the feet but it isn't. At least the feet that I have are a little taller than 2mm so it grips without being prone to tipping over.

This took me under 3 hours to print. **Print 1 "body" and 2 "arms."**

***Please post your makes and comments***

**No Supports Needed.**

# Print Settings

Printer: Hatchbox Alpha
Rafts: No
Supports: No
Resolution: 0.20mm
Infill: 33% but doesn't really matter

# Post-Printing

## Assembly

Just slide each arm on to the base.

You can use 1 or 2 rubber bands. If using 1 larger rubber band, feed it through both arms and secure on each side. (see my original design). If using 2 rubber bands, just feed it through 1 arm and secure both ends to the same post (see the photos for this design). ***I suggest the 2 rubber band method***