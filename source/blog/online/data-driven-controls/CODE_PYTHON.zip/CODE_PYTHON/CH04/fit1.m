function E=fit1(x0,x,y)
E=max(abs( x0(1)*x+x0(2)-y ));