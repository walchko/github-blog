function xkplusone = logistic(xk,r)
xkplusone = r*xk*(1-xk);