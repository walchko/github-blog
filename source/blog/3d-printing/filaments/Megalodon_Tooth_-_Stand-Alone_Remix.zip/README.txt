                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1340209
Megalodon Tooth - Stand-Alone Remix by TheMegalodonDentist is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

I loved mtdna's tooth model and so did my son - but he wanted a smaller, stand-alone version to pocket.  I wanted to be able to print them bulk as gifts for other children.  Here is that Megalodon tooth modified with MeshLab 1.3.3 to remove the base and repair some holes in the mesh.  This prints great stand-alone and in sets.

With my slicing software, I was unable to get a small print from the source as the beam connecting the tooth to the stand was thin, and vanished at a certain scale.
Enjoy, CC license mirroring mtdna's choice.

I am the Megalodon Dentist!

# Print Settings

Printer Brand: Printrbot
Printer: Simple Black
Rafts: Yes
Supports: Yes
Resolution: 0.40mm

Notes: 
I have had the most success by re-orientating the model so the tip is pointing up, and generating supports under the tooth root.  Don't worry about the raft - I print EVERYTHING with a raft whether it needs it or not.
I have not had significant success printing this model in a flat orientation.

# How I Designed This

Through the Magic of the Internet.  Also MeshLab. All glory to the Hypnotoad! Er, I mean, to mtdna!